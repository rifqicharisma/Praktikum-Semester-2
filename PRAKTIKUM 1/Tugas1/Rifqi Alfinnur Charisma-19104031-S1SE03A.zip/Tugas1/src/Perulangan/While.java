package Perulangan;

public class While {
    /*
    program yang digunakan untuk memahami perulangan while
     */
    public static void main(String[] args) {
        int nilai = 1;
        while (nilai <= 10) {
            System.out.print("Angka : " + nilai);
            nilai++;
            System.out.print("\n");
        }
    }
}
