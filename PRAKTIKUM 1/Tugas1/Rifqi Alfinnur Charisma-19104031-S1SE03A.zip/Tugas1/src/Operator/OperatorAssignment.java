package Operator;

public class OperatorAssignment {
    /*
    Operator assigment memberikan nilai
    pada sebuah variabel yang ada di sebelah kiri
    dengan nilai yang ada di sebelah kanan.
     */
    public static void main(String[] args) {
        int mData1 = 2;
        int mData2 = 19;
        System.out.println("Data pada mData1 adalah ->> " + mData1);
        System.out.println("Data pada mData2 adalah ->> " + mData2);
    }
}
