package Operator;

public class OperatorAritmatika {
    /*
    program untuk mengetahui jenis dan fungsi
    dari operand matematika
     */
    public static void main(String[] args) {
        System.out.println("Operasi Penjumlahan");
        int hasilPenjumlahan = 5 + 1;
        System.out.println("Hasil 5 + 1 = " + hasilPenjumlahan);
        System.out.println();
        System.out.println("Operasi Pengurangan");
        int hasilPengurangan = 4 - 1;
        System.out.println("Hasil 4 - 1 = " + hasilPengurangan);
        System.out.println();
        System.out.println("Operasi Pengalian");
        int hasilPengalian = 5 * 5;
        System.out.println("Hasil 5 * 5 = " + hasilPengalian);
        System.out.println();
        System.out.println("Operasi Pembagian");
        int hasilPembagian = 20 / 2;
        System.out.println("Hasil 20 / 2 = " + hasilPembagian);
        System.out.println();
        System.out.println("Operasi Habis bagi");
        int hasilSisa = 8 % 2;
        System.out.println("Hasil 8 % 2 = " + hasilSisa);
        System.out.println();
        int hasilSisa2 = 9 % 2;
        System.out.println("Hasil 9 % 2 = " + hasilSisa2);
        System.out.println();
    }
}
