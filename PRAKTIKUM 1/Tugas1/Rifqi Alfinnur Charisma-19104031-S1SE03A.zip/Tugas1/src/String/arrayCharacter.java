package String;

public class arrayCharacter {
    public static void main(String[] args) {
        //membuat variabel string dari array character
        char[] dicodingChar = { 'd', 'i', 'c', 'o', 'd', 'i', 'n', 'g' };
        String dicodingString = new String(dicodingChar);
        System.out.println(dicodingString);
    }
}
