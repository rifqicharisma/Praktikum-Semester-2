package String;

public class mengambilKarakter {
    public static void main(String[] args) {
        /*
        program untuk mengambil sebuah karakter dari string
         */
        String dicoding = "dicoding";
        char result = dicoding.charAt(7);
        System.out.println(result);
    }
}
