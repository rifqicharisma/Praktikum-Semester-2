package String;

public class panjangString {
    public static void main(String[] args) {
        /*
        membuat program untuk mengetahui panjang string
         */
        String dicoding = "dicoding";
        int length = dicoding.length();
        System.out.println(length);
    }
}
