package StrukturDasar.Musik;

public class Gitar {
    //membuat kelas bunyi gitar
    public static void bunyi(){
        System.out.println("jrenggg..");
    }
}
