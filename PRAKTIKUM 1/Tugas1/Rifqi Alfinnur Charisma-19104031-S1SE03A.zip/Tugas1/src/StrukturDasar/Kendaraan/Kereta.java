package StrukturDasar.Kendaraan;

public class Kereta {
    //membuat kelas kereta
    public static void jumlahBan() {
        System.out.println("Ban kereta banyak!");
    }
}
