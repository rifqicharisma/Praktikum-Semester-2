package StrukturDasar.Kendaraan;

public class Mobil {
    //membuat kelas mobil
    public static void jumlahBan(){
        System.out.println("Ban mobil 4");
    }
}
