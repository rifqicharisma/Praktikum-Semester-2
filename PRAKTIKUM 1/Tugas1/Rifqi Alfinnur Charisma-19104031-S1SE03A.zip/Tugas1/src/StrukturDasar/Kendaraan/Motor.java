package StrukturDasar.Kendaraan;

public class Motor {
    //membuat kelas motor
    public static void jumlahBan() {
        System.out.println("Ban motor 2");
    }
}
