package TipeData;

public class Reference {
    public static void main(String[] args) {
        /*
        tipe data yang merujuk ke sebuah objek atau instance dari sebuah class
         */
        Primitif user = new Primitif();
    }
}
