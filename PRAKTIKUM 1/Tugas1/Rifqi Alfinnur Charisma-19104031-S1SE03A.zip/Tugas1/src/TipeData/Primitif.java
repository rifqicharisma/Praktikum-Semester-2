package TipeData;

public class Primitif {
    public static void main(String[] args) {
        /*
        tipe data byte
         */
        byte a = 10;
        byte b = -10;
        /*
        tipe data short
         */
        short c = 1500;
        short d = -200;
        /*
        tipe data integer
         */
        int e = 150000;
        int f = -200000;
        /*
        tipe data long
         */
        long g = 150000L;
        long h = -200000L;
        /*
        tipe data float
         */
        float i = 3.5f;
        /*
        tipe data double
         */
        double j = 5.0;
        /*
        tipe data boolean
         */
        boolean k = true;
        boolean l = false;

    }
}
