package InputOutput;

public class UserOutput {
    /*
    program untuk mengetahui perbedaan print dengan println
     */
    public static void main(String[] args) {
        System.out.println("Dicetak pakai println()");
        System.out.println("Ini juga dicetak pakai println()");
        System.out.print("Ini dicetak dengan print()");
        System.out.print("Dan ini juga dicetak dengan print()");
    }
}
