package Percabangan;

public class IfThen {
    /*
    program untuk mengetahui struktur if then
    dalam bahasa java
     */
    public static void main(String[] args) {
        boolean isOn = true;
        if (isOn) {
            System.out.println("Menyalakan lampu");
        }
    }
}
