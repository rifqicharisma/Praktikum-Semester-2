package Percabangan;

public class IfThenElse {
    /*
    program digunakan jika statemen 1 bernilai true dan lainnya false
    maka akan dieksekusi oleh else
     */
    public static void main(String[] args) {
        boolean isOn = false;
        if (isOn) {
            System.out.println("Menyalakan lampu");
        } else {
            System.out.println("Kondisi tidak terpenuhi...");
        }
    }
}
